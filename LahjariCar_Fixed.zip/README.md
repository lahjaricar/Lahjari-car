# Lahjari Car Static Website

This is a multilingual static website for Lahjari Car (Arabic, French, English).

## Structure

- `/ar/` Arabic version
- `/fr/` French version
- `/en/` English version

## Hosting

You can host this site on GitHub Pages or any static hosting service.
