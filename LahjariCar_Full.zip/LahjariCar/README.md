
# Lahjari Car - Multi-language Website

## Structure
- `ar/`, `fr/`, `en/`: Contain localized HTML pages.
- `assets/images/`: Placeholder images for the fleet.
- `assets/icons/`: Social media icons.
- `lang-switcher.js`: Simple language switcher.

## Usage
Open the appropriate `index.html` in your browser, or serve via localhost to view full functionality.
