
function switchLanguage(lang) {
  window.location.href = '/' + lang + '/index.html';
}
